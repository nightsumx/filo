# lite-monaco

**轻量 Monaco 向代码编辑器** —— 观感接近 VS Code / Monaco，体积与依赖更小。

| | |
|---|---|
| **npm** | [`lite-monaco`](https://www.npmjs.com/package/lite-monaco) **0.3.0** |
| **内核** | CM7：移植、改写自 CodeMirror 6 的内核（文档模型、事务、输入处理），不依赖 `@codemirror` 包。来源见 [THIRD-PARTY-NOTICES.md](./THIRD-PARTY-NOTICES.md) |
| **高亮** | Shiki（peer，懒加载）。库可在 SSR 环境导入；编辑器本身只能在浏览器挂载，没有服务端出 HTML 的接口 |
| **智能** | TS/JS LanguageService（`typescript` 可选 peer） |

> **状态：`0.3` 嵌入场景可替代 Monaco（见 ENDPOINT.md）。** **不是** drop-in，也不是 VS Code 平台。  
> 仓库目录仍叫 `litcode`；**安装名是 `lite-monaco`**。
>
> **独立项目，与微软、Monaco Editor、VS Code 无关。** Monaco 和 VS Code 是微软的产品名；这里只用来说明它的手感对标谁。

## 安装

```bash
npm i lite-monaco shiki
# TS/JS 补全 · hover · 诊断 · 跳转：
npm i typescript
```

| 产物 | 约 |
|---|---|
| npm tarball | **~0.9 MB**（不内嵌 typescript / shiki） |
| `dist/index.js` | **~1.5 MB** 未 gzip，gzip 后约 400 KB（`monaco-editor` 0.52 的 `editor.main.js` gzip 约 950 KB，另有 TS worker） |

## API 稳定面

| 符号 | 稳定性 | 说明 |
|---|---|---|
| `litcode` / `litcodeThemeCSS` | **stable** | 产品主入口 |
| `DiffEditor` | **stable** | 并排 Diff（照 Monaco DiffEditorWidget） |
| `core` 命名空间（EditorView/State 等） | **stable** | 内核；少数字段仍可能扩展 |
| TS 高级（`getTSService` 等） | **stable-ish** | 依赖 optional peer |

## 快速接入

```ts
import { createHighlighter } from 'shiki'
import { litcode } from 'lite-monaco'

const highlighter = await createHighlighter({ themes: ['dark-plus'], langs: ['typescript'] })
const view = litcode({
  parent: document.getElementById('editor')!,
  options: { automaticLayout: true }, // 容器尺寸变了自动重排(Monaco 默认 false,要自己调 layout())
  highlighter,
  doc: 'const hello = "world"\n',
  lang: 'typescript',
  theme: 'dark-plus',
})
```

### 容器尺寸与主题

- **`parent` 要有确定的高度**（同 Monaco）：`.cm-editor` 是 `height: 100%; min-height: 0`，填满容器、在容器内滚动。容器是 flex 子项时给 `flex: 1; min-height: 0`；容器没有高度时编辑器高度为 0，不会再按文档撑开。
- 主题按实例：结构 CSS 全页只注入一份（`<style id="litcode-base">`），颜色是挂在每个 `.cm-editor` 上的 `--lc-*` 变量，同页一暗一亮互不影响。挂到 body 的浮层（补全、右键菜单、命令面板）会抄一份所属编辑器的变量。
- 颜色来源依次是：宿主 `colors`（`bg`/`fg`/`shell`/`vscode`）→ shiki 主题的 VS Code `colors` 表 → VS Code 默认值（Dark+/Light+）。键名就是 VS Code 的（如 `colors.vscode['editorWidget.background']`）。
- `tab-size` 跟 `EditorState.tabSize`（变量 `--lc-tab-size`）。
- `litcodeThemeCSS(colors)` 仍可用：返回结构 CSS + 一组全局生效的变量，适合不经 `litcode()` 直接用内核的场景。

### `LitCodeFeatures`（默认全开，传 `false` 关）

`lineNumbers` · `foldGutter` · `activeLine` · `multiCursor` · `bracketMatch` · `closeBrackets` · `indentOnInput` · `bracketColors` · `overviewRuler` · `minimap` · `selectionMatch` · `indentGuide` · `search` · `autocomplete` · `hover` · `history` · `tabIndent` · `hScrollbar` · `vScrollbar` · `contextMenu` · `signatureHelp` · `tsDiagnostics` · `lineWrapping`（默认关）· `stickyScroll` · `codeActions` · `a11y`

## DiffEditor

```ts
import { DiffEditor } from 'lite-monaco'

const diff = new DiffEditor({
  parent,
  highlighter,                  // 和 litcode() 一样:shiki 高亮器 + lang + theme
  lang: 'typescript',
  theme: 'dark-plus',
  original: oldText,
  modified: newText,
  // 下面都是 Monaco 默认值
  originalEditable: false,
  ignoreTrimWhitespace: true,
  renderIndicators: true,       // 行号右侧的 + / −
  renderGutterMenu: true,       // 两侧之间的 Revert Block / Revert Selection
  renderOverviewRuler: true,
  enableSplitViewResizing: true,
})
diff.modifiedView               // 两侧都是普通的 litcode 编辑器
diff.getMappings()              // Monaco advanced diff 的 LineRangeMapping
diff.goToNextChange()
```

结构 CSS 由 `litcode()` 统一注入，颜色走 `diffEditor.*` 主题键。没有 inline 模式、moved 块、accessible diff viewer，也不会在窄于 900px 时自动切成 inline。

本地：`npm run dev` → http://localhost:5199 （主路径零 Monaco）· `/diff.html` 左右对照。

## 从 Monaco 迁移

见 **[MIGRATION.md](./MIGRATION.md)**。React 示例：**[examples/react-basic.tsx](./examples/react-basic.tsx)**。

## 已有 / 未做

| 有 | 说明 |
|---|---|
| 编辑核心 | rope/state/view/输入/命令/虚拟视口 |
| Monaco 向 UI | 行号、折叠、minimap、滚动条、find、命令面板 |
| 语言 | Shiki；TS/JS 补全/hover/诊断/peek/fix |
| Diff | side-by-side，Monaco 的 diff 算法、对齐、gutter 菜单、概览尺 |
| a11y | role/textbox、live region |

| 不做 | 说明 |
|---|---|
| Monaco API 全集 | 不是 drop-in，用 `litcode()` / `DiffEditor` |
| contribution / worker 平台 | 永久不做 |
| multi-tab model 服务 | 宿主自管 |
| inline / moved-block Diff、accessible diff viewer | 未做 |

## 开发

```bash
npm run dev    # :5199
npm test
npm run build
```

| 文档 | |
|---|---|
| [ROADMAP.md](./ROADMAP.md) | 迭代 TODO |
| [MIGRATION.md](./MIGRATION.md) | Monaco 迁移 |
| [PERF.md](./PERF.md) | 大文档预算 |
| [CAPABILITIES.md](./CAPABILITIES.md) | 能力表 |
| [src/ARCHITECTURE.md](./src/ARCHITECTURE.md) | 源码分层 |
| [CHANGELOG.md](./CHANGELOG.md) | 版本 |

## License

MIT. Parts are ported from CodeMirror 6 and the Monaco Editor / VS Code (both MIT); their notices are in [THIRD-PARTY-NOTICES.md](./THIRD-PARTY-NOTICES.md).
